#!/usr/bin/env bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

ip=""
port=60000
pass="Test"
confd_pass=""


Green_font_prefix="\033[32m" && Red_font_prefix="\033[31m" && Green_background_prefix="\033[42;37m" && Red_background_prefix="\033[41;37m" && Font_color_suffix="\033[0m"
Info="${Green_font_prefix}[信息]${Font_color_suffix}"
Error="${Red_font_prefix}[错误]${Font_color_suffix}"
Tip="${Green_font_prefix}[注意]${Font_color_suffix}"

check_root(){
	[[ $EUID != 0 ]] && echo -e "${Error} 当前非ROOT账号(或没有ROOT权限)，无法继续操作，请更换ROOT账号或使用 ${Green_background_prefix}sudo su${Font_color_suffix} 命令获取临时ROOT权限（执行后可能会提示输入当前账号的密码）。" && exit 1
}

yum_install(){
	echo -e "--------yum依赖安装开始-----------"
	# 检测yum是否可用
	[ $(yum repolist | awk '/repolist/{print$2}' | sed 's/,//') -eq 0 ] && echo "${Error} yum源存在问题 !" && exit 2
	# 开始安装依赖
	for i in gcc pcre pcre-devel zlib zlib-devel openssl openssl-devel gcc-c++ supervisor screen inotify-tools epel-release nginx
	do
		rpm -qa | grep ${i%%.*} &>/dev/null
		[ $? -eq 0 ] || yum install -y $i&>/dev/null && echo -e "${Info} "$i"安装完成 !"
		[ $? -ne 0 ] && echo -e "${Error} yum安装 "$i"失败 !"&& exit 3
	done
}

install_ss_server(){
	echo -e "-------------------------------"
	if [[ -x /root/ss-server ]]; then
		echo -e "${Tip} 已经安装ss-server，跳过 !"
	else
		cp ss-server /root/ss-server
		chmod +x /root/ss-server
		echo -e "${Info} ss-server 安装成功 !"
	fi
}

install_confd(){
	if [[ -x /usr/bin/confd ]]; then
		echo -e "${Tip} 已经安装confd，跳过 !"
	else
		cp confd /usr/bin/confd
		chmod +x /usr/bin/confd
		echo -e "${Info} confd 安装成功 !"
	fi
}

copy_config(){
	echo -e "-------------------------------"
	mkdir -p /etc/confd/{conf.d,templates}
	cp -f conf.d/* /etc/confd/conf.d
	cp -f templates/* /etc/confd/templates
	cp -f custom_config.json /root/custom_config.json
	cp -f 2.sh /root/2.sh
	cp -f supervisord.conf /etc/supervisord.conf
	cp -f config.json /root/config.json	

	sed -i "s/1.1.1.1/${ip}/g" /etc/supervisord.conf
	sed -i "s/this_is_confd_password/${confd_pass}/g" /etc/supervisord.conf
	sed -i "s/60000/${port}/g" /root/config.json
	sed -i "s/Test/${pass}/g" /root/config.json
	echo -e "${Info} 配置文件迁移完成 !"
}

autorun(){
	echo -e "-------------------------------"
	systemctl enable nginx.service &>/dev/null
	if [ $? -ne 0 ]; then
	    echo -e "${Error} nginx自启配置失败 !" && exit 1
	else
	    echo -e "${Info} nginx自启配置成功 !"
	fi

	systemctl enable supervisord.service &>/dev/null
	if [ $? -ne 0 ]; then
	    echo -e "${Error} supervisord自启配置失败 !" && exit 1
	else
	    echo -e "${Info} supervisord自启配置成功 !"
	fi

	systemctl start nginx &>/dev/null
	if [ $? -ne 0 ]; then
	    echo -e "${Error} nginx 启动失败 !" && exit 1
	else
	    echo -e "${Info} nginx 启动成功 !"
	fi

	systemctl start supervisord &>/dev/null
	if [ $? -ne 0 ]; then
	    echo -e "${Error} supervisord 启动失败 !" && exit 1
	else
	    echo -e "${Info} supervisord 启动成功 !"
	fi

	echo -e "--------------完成----------------"
	echo -e "${Info} 顺利完成安装 !!!"
	echo -e "${Tip} 你可以查看nginx配置是否同步成功：cat /etc/nginx/nginx.conf "
}

# 检查root权限
check_root

# 接收参数
if [[ $1 = "-i" ]]; then
	ip=$2
elif [[ $1 = "-port" ]]; then
	port=$2
elif [[ $1 = "-confd_pass" ]]; then
	confd_pass=$2
elif [[ $1 = "-pass" ]]; then
	pass=$2
fi


if [[ $3 = "-i" ]]; then
	ip=$4
elif [[ $3 = "-port" ]]; then
	port=$4
elif [[ $3 = "-confd_pass" ]]; then
	confd_pass=$4
elif [[ $3 = "-pass" ]]; then
	pass=$4
fi


if [[ $5 = "-i" ]]; then
	ip=$6
elif [[ $5 = "-port" ]]; then
	port=$6
elif [[ $5 = "-confd_pass" ]]; then
	confd_pass=$6
elif [[ $5 = "-pass" ]]; then
	pass=$6
fi


if [[ $7 = "-i" ]]; then
	ip=$8
elif [[ $7 = "-port" ]]; then
	port=$8
elif [[ $7 = "-confd_pass" ]]; then
	confd_pass=$8
elif [[ $7 = "-pass" ]]; then
	pass=$8
fi


if [[ ${#ip} -lt 7 ]]; then
	echo -e "${Error} ip填写不正确 !"
	echo -e "${Error} 使用方法 ./install.sh -i <ip地址> -port(选用) <端口号(默认60000)> -pass(选用) <ss密码(默认Test)> -confd_pass <confd密码>" && exit 1
fi
if [[ ${#port} -eq 0 ]]; then
	echo -e "${Error} 请填写端口 !"
	echo -e "${Error} 使用方法 ./install.sh -i <ip地址> -port(选用) <端口号(默认60000)> -pass(选用) <ss密码(默认Test)> -confd_pass <confd密码>" && exit 1
fi
if [[ ${#confd_pass} -eq 0 ]]; then
	echo -e "${Error} 请填写confd密码 !"
	echo -e "${Error} 使用方法 ./install.sh -i <ip地址> -port(选用) <端口号(默认60000)> -pass(选用) <ss密码(默认Test)> -confd_pass <confd密码>" && exit 1
fi
if [[ ${#pass} -eq 0 ]]; then
	echo -e "${Error} 请填写ss密码 !"
	echo -e "${Error} 使用方法 ./install.sh -i <ip地址> -port(选用) <端口号(默认60000)> -pass(选用) <ss密码(默认Test)> -confd_pass <confd密码>" && exit 1
fi

echo -e "${Info} 请检查配置：ip为 [${ip}]，端口为 [${port}]，ss密码为 [${pass}]，confd密码为 [${confd_pass}] !"


# yum安装依赖（包括supervisor + nginx）
yum_install

# 安装ss-server
install_ss_server

# 安装confd
install_confd

# 复制config文件
copy_config

# 启动并添加开机自启 supervisor + nginx
autorun
