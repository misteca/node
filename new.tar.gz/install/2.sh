#!/bin/bash
src=/etc/nginx/
while true
    do
    inotifywait -rq -e modify $src |  if read file
    then
        echo '配置文件改变，15s后重启confd'+`date +%Y-%m-%d,%H:%M`
        sleep 15
        pkill -f confd
        echo '已重启'
        sleep 3
    fi
    done
