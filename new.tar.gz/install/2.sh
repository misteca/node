#!/bin/bash
while true
    do
    str=$(tail -1 /opt/confd.log)
    if [[ ( $str == *"ERROR"* ) || ( $str == *"WARNING"*) ]]
    then
        echo '第一次检测到错误'+`date +%Y-%m-%d,%H:%M`
        sleep 3
        str=$(tail -1 /opt/confd.log)
        if [[ ( $str == *"ERROR"* ) || ( $str == *"WARNING"*) ]]
        then
            echo '第二次检测到错误，重启confd'+`date +%Y-%m-%d,%H:%M`
            pkill -f confd
            echo '已重启'
        else
            echo '第二次检测正常'
        fi
    else
        sleep 5
    fi
    done
